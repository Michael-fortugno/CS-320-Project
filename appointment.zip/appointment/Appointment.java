package appointment;
import java.util.Calendar;
import java.util.Date;



public class Appointment {
	private String appointmentDescription;
	private Date appointmentDate;
	private  String appointmentID;
	
	
	
// constructor will take in appt date and desription as parameter
	public Appointment(String apptID, Date apptDate, String apptDescription) {
		if(apptID == null || apptID.length()> 10) {
			throw new IllegalArgumentException("Invalid ID");
			
			
		}
		appointmentID = apptID;
		
		
		if(apptDate == null) {
			throw new IllegalArgumentException("Invalid Date");
		}
		else if(apptDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid  Date");
			
		}
		else {
		appointmentDate = apptDate;
		
		}
		if(apptDescription == null || apptDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid  Description");
		}
		
		
		appointmentDescription = apptDescription;
	}
	
	// getter methods
	
		public String getAppointmentID() {
			return appointmentID;
		}
		
		
		public String getAppointmentDescription() {
			return appointmentDescription;
		}
		
		public Date getAppointmentDate() {
			return appointmentDate;
		}
		
		

		//setter methods
		
		void setAppointmentID(String apptID) {
			if(apptID == null || apptID.length()> 10) {
				throw new IllegalArgumentException("Invalid ID");
				
			}
			appointmentID = apptID;
			
		}
		void setAppointmentDate(Date apptDate) {
			
			if(apptDate == null) {
				throw new IllegalArgumentException("Invalid Date");
			}
			else if(apptDate.before(new Date())) {
				throw new IllegalArgumentException("Invalid Date");
				
			}
			else {
				appointmentDate = apptDate;
			}
		}
		
			
			
		
			
		
		void setAppointmentDescription(String apptDescription) {
			if(apptDescription == null || apptDescription.length() > 50) {
				throw new IllegalArgumentException("Invalid Description");
			}
			appointmentDescription = apptDescription;
		}
			

	}
			
		
		
		
		
	
	
	
	
