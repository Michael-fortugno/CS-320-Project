package appointment;
import java.util.Date;

import java.util.Random;
import java.util.ArrayList;



public class AppointmentService {
	// array to hold appointment information
	private ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	// count variable to hold amount of appointments exist limit will be 10 characters
	private int count;
	
	
	
	//getters
	public int getCount() {
		return count;
	}
	
	public ArrayList getAppointmentList() {
		return appointmentList;
	}
	// method to print array holding appointments
	public void PrintAppointmentList() {
		for (int i = 0; i < appointmentList.size(); i++) {
			System.out.println("Appointment ID: " + appointmentList.get(i).getAppointmentID() +
					"\nAppointment Date: " + appointmentList.get(i).getAppointmentDate().toString() +
					"\nAppointment Description: " + appointmentList.get(i).getAppointmentDescription());
		}
	}
	
	// generate a unique id number for the created appointment
	// give id max length of 10 characters
			public String uniqueID() {
				int count = 0;
				
				
				// grabs a random number max of 10 characters and creates ID turns int to string
				Random rand = new Random();
				int newID = rand.nextInt(1000000000);
				String uniqueID = Integer.toString(newID);
				
				
				// array to hold ID's
				ArrayList<String> idList = new ArrayList<String>();
				// loop to grab ID's
				for ( int i = 0; i < appointmentList.size(); i++) {
					appointmentList.get(i).getAppointmentID();
				}
				
				// checks if a specific ID exists
				while (idList.contains(uniqueID) || uniqueID.length() > 10) {
					// if  found, create a new id
					newID = rand.nextInt(1000000000);
					uniqueID = Integer.toString(newID);
					count++;
					if (count > 1000000000) {
						System.out.println("No more ID's avaliable");
						break;
					}
				}
				
				idList = null;
				// return created id
				return uniqueID;
			}
	
	// add appointment checking for requirnement conditions
		public void AddAppointment(Date date, String description) {
			Date today = new Date();
			if (date == null ) {
				throw new IllegalArgumentException("Invalid Date");
			}
			
			else if(date.before(today)) {
				throw new IllegalArgumentException("Invalid Date");
				
			}
			if (description == null  ) {
				throw new IllegalArgumentException("Invalid Description");
				
			}
			
			else if(description.length() > 50) {
				throw new IllegalArgumentException("Invalid Description");
			}
			String newID = uniqueID();
			var newAppt = new Appointment(newID, date, description);
			appointmentList.add(newAppt);
			count = getCount() + 1;
			System.out.println("Appointment " + description + " created.");
		}
		
		// remove appointments, check for condtions
		public void RemoveAppointment(String id) {
			if (appointmentList.isEmpty()) {
				System.out.println("There are no appointments to remove.");
				
				
			}
			if (id == null ) {
				throw new IllegalArgumentException("Invalid ID");
				
			}
			
			else if(id.length() > 10) {
				throw new IllegalArgumentException("Invalid ID");
				
			}
			
			// search id's for specified appointment
			int index = -1;
			for (int i = 0; i < appointmentList.size(); i++) {
				if (appointmentList.get(i).getAppointmentID() == id) {
					index = appointmentList.indexOf(i);
				}
				
			}
			// appointment wasn't found
			if (index == -1) {
				System.out.println("Appointment ID not found.");
				return;
			}
			else {
				//remove the appointment
				appointmentList.remove(index);
				count = getCount() - 1;
				System.out.println("Appointment removed");
			}
		}
		
		
		

	
	

	
}

