package test;

import java.util.Calendar;
import java.util.Date;
import appointment.Appointment;
import appointment.AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
	// create a date to test
	Date createADate() {
		Calendar cal = Calendar.getInstance();
		cal.set(2024, 3, 15, 9, 15);
		Date date = cal.getTime();
		return date;
	}
	// invalid date
	Date badDate() {
		Date date = new Date();
		date.setTime(1000000);
		return date;
	}

	@Test
	// test add appointment
	void testAddAppointment() {
		var apptService = new AppointmentService();
		assertTrue(apptService.getAppointmentList().isEmpty());
		assertEquals(apptService.getCount(), 0);
		
		apptService.AddAppointment(createADate(), "Description");		
		apptService.PrintAppointmentList();
	}
	
	@Test
	// test for null date
	void testAddAppointmentNullDate() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(null, "Description");
		});
	}
	
	
	@Test
	// test null description
	void testAddAppointmentNullDescription() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(createADate(), null);
		});
	}
	
	
	@Test
	// test for invalid date
	void testAddAppointmentInvalidDate() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(badDate(), "Description");
		});
	}
	
	@Test
	// test for invalid description
	void testAddAppointmentInvalidDescription() {
		var apptService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.AddAppointment(createADate(), "thisisadescriptiont"
					+ "is reallyreallyreallyreallyreallyreallyreallylong.");
		});
	}
	
	@Test
	// for valid conditiions
	void testAddAppointmentWithValidParameters() {
		var apptService = new AppointmentService();
		
		apptService.AddAppointment(createADate(), "This is a good description");
		assertEquals(apptService.getCount(), 1);
		assertTrue(!apptService.getAppointmentList().isEmpty());
		apptService.PrintAppointmentList();
		
		
	}
	
	// test for deleting appoinment
	@Test
	// test for empty list
	void testRemoveListEmpty() {
		var apptService = new AppointmentService();
		// list is empty
		apptService.RemoveAppointment("1234567");
	}
	
	
	@Test
	//test for null id
	void testRemoveIDNull() {
		var apptService = new AppointmentService();
		apptService.AddAppointment(createADate(), "TO REMOVE");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.RemoveAppointment(null);
		});
	}
	
	@Test
	// test for id too long
	void testRemoveIDTooLong() {
		var apptService = new AppointmentService();
		apptService.AddAppointment(createADate(), "TO REMOVE");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			apptService.RemoveAppointment("1234567800090000");
					
		});
	}
	
	@Test
	//test remove an id not in array
	void testRemoveAppointmentNotInList() {
		var apptService = new AppointmentService();
		apptService.AddAppointment(createADate(), "TO REMOVE");
		apptService.RemoveAppointment("1234567");
		assertTrue(!apptService.getAppointmentList().isEmpty());
	}
	
	
	
	

	
	

}
