package test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Calendar;

import appointment.Appointment;


class AppointmentTest {
	
	

	@Test
	void testAppointment() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(2024, 3,15, 11, 11);
		Date date = calendar.getTime();
		
		System.out.println("Date = " + date);
		
		//id too long
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					new Appointment("12345678900", date, "Appointment Description");
				});
		
		//description too long
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					new Appointment("15", date , "Thisisadescription"
							+ "reallyreallyreallyreallyreallyreallyreallylong");
				});
				
				//description null
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					new Appointment("1234567890", date , null);
				});
				
				//date null
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					new Appointment("1234567890", null , "Appointmentt Description");
				});
				//date before today
				
				date.setTime(1);
				System.out.println("Date set to " + date);
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					new Appointment("1234567890", date , "Appt Description");
				});
	}
	
	

}
