package contact;


public class Contact {
	
	// TODO Auto-generated constructor stub
	private String contactId;				//cannot be >10 char
	private String contactFirstName;		//cannot be >10 char
	private String contactLastName;		//cannot be >10 char
	private String contactPhoneNumber;	//must be exactly 10 char
	private String contactAddress;		//cannot be >30 char
	

	public Contact(String id, String fName, String lName, String phoneNumber, String address) {
		//String newid = GenerateUniqueID();
		
		if(id == null ) {
			throw new IllegalArgumentException("Invalid ID");
		}
		else if(id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
			
		}
		if(fName == null) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		else if(fName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		if(lName == null) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		else if(lName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		if(phoneNumber == null) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		else if(phoneNumber.length() < 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
			
		}
		if(address == null) {
			throw new IllegalArgumentException("Invalid Address");
		}
		else if(address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		
		contactId = id;
		contactFirstName = fName;
		contactLastName = lName;
		contactPhoneNumber = phoneNumber;
		contactAddress = address;
	}
	
	
			
	

		
	
	
	// getter methods
	public String getContactID() {
		return contactId;
	}
	public String getFirstName() {
		return contactFirstName;
	}
	public String getLastName() {
		return contactLastName;
	}
	public String getPhoneNumber() {
		return contactPhoneNumber;
	}
	public String getAddress() {
		return contactAddress;
	}
	
	// setter methods
	
	// firstname setter uses same checks as constructor 
	public void setFirstName(String fName) {
		if(fName == null) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		else if(fName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		contactFirstName = fName;
	}
		
		
	
	
	// last name setter
	// uses same checks as constructor
	public void setLastName(String lName) {
		if(lName == null) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		else if(lName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		contactLastName = lName;
		
	}
	
	// address setter
	// uses same checks as constructor
	public void setAddress(String address) {
		
		if(address == null) {
			throw new IllegalArgumentException("Invalid Address");
		}
		else if(address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		contactAddress = address;
		
	}
	
	// phone number setter 

	public void setPhoneNumber(String phoneNumber) {
		if(phoneNumber == null) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		else if(phoneNumber.length() < 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
			
		}
		contactPhoneNumber = phoneNumber;
	
	}

	

}
