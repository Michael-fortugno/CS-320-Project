package contact;
import java.util.Random;
import java.util.ArrayList;

public class ContactService {
	private int contactCount = 0;
	// arraylist to hold contacts
	public ArrayList<Contact> contactList = new ArrayList<Contact>();
	// method to print the contact list using a for loop 
	public int getContactCount() {
		return contactCount;
	}
	
	public ArrayList<Contact> getContactList(){
		return contactList;
	}
	// method to add contact to list and a counter variable to hold size of list
	public void addContact(String id, String fName, String lName, String phoneNumber, String address) {
		Contact newContact = new Contact(
				id,
				fName,
				lName,
				phoneNumber,
				address);
		
		contactList.add(newContact);
		contactCount++;
	}
	public void addContact(Contact contact) {
		contactList.add(contact);
		contactCount++;
	}
	// method to delete a contact
	public void deleteContact(String id) {
		if(id == null) {
			throw new IllegalArgumentException("Invalid ID");
			
		}
		else if(id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
			
		}
		
		if(contactList.isEmpty()) {
			throw new IllegalArgumentException("No contacts to delete");
		}
		
		int indx = -1;
		for (Contact i : contactList) {
			if (i.getContactID() == id) {
				indx = contactList.indexOf(i);
			}
			
		}
		if (indx == -1) {
			System.out.println("Contact not found.");
			return;
		}
		else{
			contactList.remove(indx);
			contactCount--;
			System.out.println("Contact removed from list.");
		}
		
		
	}
	private void deleteContact(Contact contact) {
		contactList.remove(contact);
		contactCount--;
	}
	
	//method to update contact
	public void updateContact(String id, String update, int selection) {
		if(id == null) {
			throw new IllegalArgumentException("Invalid ID");
		}
		else if(id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
			
		}
		else if(update == null) {
			throw new IllegalArgumentException("Invalid ID");
		}
		else if( selection < 0) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if(contactList.isEmpty()) {
			throw new IllegalArgumentException("No contacts exist in list");
		}
		
		int indx = -1;
		for (Contact i : contactList) {
			if (i.getContactID() == id) {
				indx = contactList.indexOf(i);
			}
			
		}
		if (indx == -1) {
			System.out.println("Contact not found.");
			return;
		}
		
		Contact updateContact = contactList.get(indx);
		
		switch (selection){
		case 1:{
			updateContact.setFirstName(update);
			break;
		}
		case 2:{
			updateContact.setLastName(update);
			break;
		}
		case 3:{
			updateContact.setPhoneNumber(update);
			break;
		}
		case 4:{
			updateContact.setAddress(update);
			break;
		}
		default:{
			System.out.println("Invalid change.");
			break;
		}
		}
		
		deleteContact(contactList.get(indx));
		addContact(updateContact);
		
				
	}
	
	public void updateContact(String id, String fName, String lName, String phoneNumber, String address) {
		if(id == null ) {
			throw new IllegalArgumentException("Invalid ID");
		}
		else if(id.length()> 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if(contactList.isEmpty()) {
			throw new IllegalArgumentException("No contacts in list");
		}
		
		int indx = -1;
		for (Contact i : contactList) {
			if (i.getContactID() == id) {
				indx = contactList.indexOf(i);
			}
			
		}
		if (indx == -1) {
			System.out.println("Contact not found.");
			return;
		}
		
		Contact temp = contactList.get(indx);
		temp.setFirstName(fName);
		temp.setLastName(lName);
		temp.setAddress(address);
		temp.setPhoneNumber(phoneNumber);
		
		contactList.remove(indx);
		contactList.add(temp);
				
	}
	
	// method to get unique id number
	public String generateUniqueID() {
		// auto generate a random ID for contact
		Random rand = new Random();
		int newID = rand.nextInt(1111111111);
		String uniqueID = Integer.toString(newID);
		
		for (Contact i : contactList) {
			while (i.getContactID() == uniqueID) {
				newID = rand.nextInt(1111111111);
				uniqueID = Integer.toString(newID);
			}
			
		}
		
		System.out.println("ID: " + uniqueID);
				
		return uniqueID;
	}
	
	
		
		
		
	
	
	
	
	
	

	

}
