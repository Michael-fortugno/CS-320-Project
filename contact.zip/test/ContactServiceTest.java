package test;

import static org.junit.jupiter.api.Assertions.*;
import contact.Contact;
import contact.ContactService;
import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testAddContact() {
		// create a contact
		ContactService contactService = new ContactService();
		String testID = contactService.generateUniqueID();
		Contact contact = new Contact(testID,"First Name", "Last Name", "1112223333","1313 MockingBirdLane");
		// add contact to  list
		contactService.addContact(contact);
		// confirm contact is in the list, count is not zero
		assertTrue(!contactService.getContactList().isEmpty());
		assertTrue(contactService
				.getContactList()
				.get(0)
				.getContactID()
				.equals(testID));
		assertTrue(contactService.getContactCount() > 0);
	}
	
	
	@Test
	void testDelete() {
		ContactService contactService = new ContactService();
		// create new contact
		Contact contact = new Contact("123456", "First Name", "Last Name", "1112223333", "1313 MockingBird lane");
		// try to remove with null id
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.deleteContact(null);
		});
		//  remove with id that's too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.deleteContact("12345678901");
		});
		//  remove from empty list
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.deleteContact("1234567890");
		});
		// add  contact
		contactService.addContact(contact);
		// remove a contact that isn't there
		contactService.deleteContact("123457");
		// contact list is not empty, count is not zero
		// contact not removed because contact doesn't exist
		assertTrue(!contactService.getContactList().isEmpty());
		assertTrue(contactService.getContactCount() != 0);
		// remove correct contact
		contactService.deleteContact("123456");
		// list is empty, count is zero, contact successfully removed
		assertTrue(contactService.getContactCount() == 0);
		assertTrue(contactService.getContactList().isEmpty());
		
	}
	
	@Test
	void testUpdateContactErrors() {
		ContactService contactService = new ContactService();
		// contact list is empty
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", "Lawrence", 1);
		});
		
		// create new contact, add to list
		Contact contact = new Contact("123456", "First Name", "Last Name", "1112223333", "1313 MockingBird Lane");
		contactService.addContact(contact);
		// check that contact added
		assertTrue(!contactService.getContactList().isEmpty());
		
		// id is too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("12345678901", "first name", 1);
		});
		// id is null
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact(null, "first name", 1);
		});
		// update value is null
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", null, 1);
		});
		// selection value is less than zero
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", "first name", -1);
		});
		
		// print "contact not found" to console
		contactService.updateContact("123457", "first name", 1);
		
		// print "contact not updated" to console
		contactService.updateContact("123456", "first name", 5);
		
	}
	
	@Test
	void testUpdateContactMethod() {
		ContactService contactService = new ContactService();
		Contact contact = new Contact("123456", "First Name", "Last Name", "1112223333", "1313 MockingBird Lane");
		contactService.addContact(contact);
		assertTrue(!contactService.getContactList().isEmpty());
		
		// update first name
		contactService.updateContact("123456", "first name", 1);
		assertTrue(contactService
				.getContactList()
				.get(0)
				.getFirstName()
				.equals("first name"));
		// update last name
		contactService.updateContact("123456", "last name", 2);
		assertTrue(contactService
				.getContactList()
				.get(0)
				.getLastName()
				.equals("last name"));
		// update phone number
		contactService.updateContact("123456", "2223334444", 3);
		assertTrue(contactService
				.getContactList()
				.get(0)
				.getPhoneNumber()
				.equals("2223334444"));
		// update address
		contactService.updateContact("123456", "123 middle of nowhere road", 4);
		assertTrue(contactService
				.getContactList()
				.get(0)
				.getAddress()
				.equals("123 middle of nowhere road"));
		
		// update first name too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contactService.updateContact("123456", "myfirstnameiswaytoolong", 1);
		});
				
	
			
					
		}

}
