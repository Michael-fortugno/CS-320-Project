package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import contact.Contact;
class ContactTest {
	
	
	@Test
	void testContactNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			new Contact(null, null, null, null, null);
		});
			
	}
	
	@Test
	void testContact() {
		Contact contact = new Contact("123456", "First Name", "Last Name", "1112223333", "1313 MockingBird lane");
		assertTrue(contact.getFirstName().equals("First Name"));
		assertTrue(contact.getLastName().equals("Last Name"));
		assertTrue(contact.getPhoneNumber().equals("1112223333"));
		assertTrue(contact.getAddress().equals("1313 MockingBird lane"));
		assertTrue(contact.getContactID().equals("123456"));
	}
	
	@Test
	void testName() {
		Contact contact = new Contact("123456", "First Name", "Last Name", "1112223333", "1313 MockingBird lane");
		contact.setFirstName("First Name");
		contact.setLastName("Last Name");
		assertTrue(contact.getFirstName().equals("First Name"));
		assertTrue(contact.getLastName().equals("Last Name"));
	}
	
	@Test
	void testPhoneNumberAndAddress() {
		Contact contact = new Contact("123456", "First Name", "Last Name", "1112223333", "1313 MockingBird lane");
		contact.setPhoneNumber("1112223333");
		contact.setAddress("1313 MockingBird lane");
		assertTrue(contact.getPhoneNumber().equals("1112223333"));
		assertTrue(contact.getAddress().equals("1313 MockingBird lane"));
	}
	
	@Test
	void testNullSet() {
		Contact contact = new Contact("123456", "First Name", "Last Name", "1112223333", "1313 MockingBird lane");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setFirstName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setLastName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setAddress(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			contact.setPhoneNumber(null);
		});
	}
	
	

	
	
	

}
		
		
		
		
			
			
		
			
				
			
		
	
	
		
		
		
		
		
	


