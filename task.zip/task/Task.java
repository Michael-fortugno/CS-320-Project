package task;
public class Task {
	
	private String taskID;
	private String taskName;
	private String taskDescription;

	// constructor with error checking
	public Task(String id, String name, String description) {
		if (id == null ) {
			throw new IllegalArgumentException("Invalid ID");
		}
		else if(id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (name == null) {
			throw new IllegalArgumentException("Invalid Name");
		}
		else if(name.length() > 20) {
			throw new IllegalArgumentException("Invalid Name");
		}
		if (description == null) {
			throw new IllegalArgumentException("Invalid Description");
		}
		else if(description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		taskID = id;
		taskName = name;
		taskDescription = description;
	}
	
	// getters
	public String getID() {
		return taskID;
	}
	public String getTaskName() {
		return taskName;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	
	// setters 
	public void setTaskName(String name) {
		if (name == null) {
			throw new IllegalArgumentException("Invalid Name");
		}
		else if(name.length() > 20) {
			throw new IllegalArgumentException("Invalid Name");
		}
		
		taskName = name;
	}
	public void setTaskDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		else if(description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		taskDescription = description;
	}
	
}
