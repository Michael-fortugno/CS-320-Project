package task;
import java.util.ArrayList;
import java.util.Random;



public class TaskService {

	private ArrayList<Task> taskList = new ArrayList<Task>();
	private int taskCount = 0;
		
	// list of tasks
	public ArrayList<Task> getTaskList() {
		return taskList;
	}
	// count of tasks
	public int getTaskCount() {
		return taskCount;
	}
	// print the tasks 
	public void PrintTaskList() {
		for (Task i : taskList) {
			System.out.println("Task ID: " + i.getID() + " Name: " + i.getTaskName());
			System.out.println("Description: " + i.getTaskDescription() + "\n");
		}
	}
	
	// add task w
	public void addTask(String tName, String tDescription) {
		if (tName == null) {
			throw new IllegalArgumentException("Invalid name");
		}
		else if(tName.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
		if (tDescription == null) {
			throw new IllegalArgumentException("Invalid description");
		}
		else if(tDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		String newID = GenerateUniqueID();
		var newTask = new Task(newID, tName, tDescription);
		taskList.add(newTask);
		taskCount = getTaskCount() + 1;
		System.out.println("Task " + newTask.getTaskName() + " created and added");
	}
	
	//  remove and add 
	private void addTask(Task task) {
		taskList.add(task);
		taskCount = getTaskCount() + 1;
	}
	private void removeTask(Task task) {
		taskList.remove(task);
		taskCount = getTaskCount() - 1;
	}
	
	// remove task by id with error checking
	public void removeTask(String id) {
		if (taskList.isEmpty()) {
			System.out.print("There are no tasks to remove");
		}
		if (id == null) {
			throw new IllegalArgumentException("Invalid ID");
		}
		else if(id.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		//search id's in list
		int index = -1;
		for (Task i : taskList) {
			if (i.getID() == id) {
				index = taskList.indexOf(i);
			}
		}
		// task wasn't found 	
		if (index == -1) {
			// output to console
			System.out.println("Task not found");
			return;
		}
		else {
			// remove the task using internal method
			taskList.remove(index);
			taskCount = getTaskCount() - 1;
			System.out.println("Task removed from list");
		}
	}
	
	// update task by id 
	public void UpdateTask(String id, String update, int selection) {
		if (id == null) {
			throw new IllegalArgumentException("Bad Request");
		}
		else if(id.length() > 10) {
			throw new IllegalArgumentException("Bad Request");
			
		}
		else if(update == null) {
			throw new IllegalArgumentException("Bad Request");
		}
		else if(selection < 0) {
			throw new IllegalArgumentException("Bad Request");
		}
		if (taskList.isEmpty()) {
			System.out.println("No tasks in list");
			return;
		}
		// find matching task 
		int index = -1;
		for (Task i : taskList) {
			if (i.getID() == id) {
				index = taskList.indexOf(i);
			}
		}
		// task not found 
		if (index == -1) {
			System.out.println("Task not found, check ID");
			return;
		}
		// create temp 
		Task updateTask = taskList.get(index);
		// conditional for what needs to be updated
		// 1 = name
		// 2 = description
		switch (selection) {
		case 1:{
			updateTask.setTaskName(update);
			break;
		}
		case 2:{
			updateTask.setTaskDescription(update);
			break;
		}
		// any other number selection
		default:{
			System.out.println(" invalid change requested.");
			break;
		}
		}
		// remove task
		removeTask(taskList.get(index));
		 //add updated task
		addTask(updateTask);
		
	}
	
	// generate a unique id number for created task
	public String GenerateUniqueID() {
		// randomize number with 9 - 10 digits
		Random rand = new Random();
		int newID = rand.nextInt(1000000000);
		String uniqueID = Integer.toString(newID);
		
		// temp list
		ArrayList<String> idList = new ArrayList<String>();
		
		for (Task i : taskList) {
			idList.add(i.getID());
		}
		// compare newly created id 
		while (idList.contains(uniqueID) || uniqueID.length() > 10) {
			// if match was found, create a new id
			newID = rand.nextInt(1111111111);
			uniqueID = Integer.toString(newID);
		}
		// remove temp 
		idList = null;
		
		return uniqueID;
	}




	
}


