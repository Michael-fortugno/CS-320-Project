package test;
import task.TaskService;
import task.Task;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void testTask() {
		var taskService = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			var newTask = new Task(null, null, null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			var newTask = new Task("123456", null, null);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			var newTask = new Task("123456", "task name", null);
		});
		// id too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			var newTask = new Task("12345678901", "task name", "task Description");
		});
		// name too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			var newTask = new Task("123456", "task name is waywaywaywaywaywayway too long ", "task Description");
		});
		// description too long
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			var newTask = new Task("123456", "name", "task Description is waywaywaywaywaywaywaywaywaywayway"
					+ " waywaywaywaywayway too long I think.");
		});
		
		// test setters
				var newTask = new Task("123456", "task Name", "task Description");
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					newTask.setTaskName(null);
				});
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					newTask.setTaskDescription(null);
				});
				
			}
	
	@Test
	void testGetters() {
		// test getters 
		var taskService = new TaskService();
		assertTrue(taskService.getTaskCount() == 0);
		assertTrue(taskService.getTaskCount() != 1);
		assertTrue(taskService.getTaskList().isEmpty());
		taskService.PrintTaskList();
	}
	
	@Test
	void addTask() {
		TaskService taskService = new TaskService();
		// null name
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			taskService.addTask(null, "task Description");
		});
		// null description
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			taskService.addTask("task Name", null);
		});
		// name too long / description too long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			taskService.addTask("name is waywaywaywaywaywaywayway too long.", "task Description");
		});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			taskService.addTask("task Name", "task description waywaywaywaywaywaywaywaywaywaywaywaywayway"
					+ "waywaywaywaywaywaywaywaywayway too long I think.");
		});
		
		// test  valid input
		taskService.addTask("task Name", "task description");
		assertTrue(taskService.getTaskCount() == 1);
		assertTrue(!taskService.getTaskList().isEmpty());
		taskService.PrintTaskList();
	}
	
	@Test
	void testRemoveTask() {
		var taskService = new TaskService();
		
		taskService.removeTask("123456");
		// null id sent
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			taskService.removeTask(null);
		});
		// id too long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			taskService.removeTask("12345678901");
		});
		// add task to remove
		taskService.addTask("new task name", "new task description");
		Task task = taskService.getTaskList().get(0);
		// task doesn't exist
		taskService.removeTask("12345");
		// task does exist
		taskService.removeTask(task.getID());
		assertTrue(taskService.getTaskCount() == 0);
		assertTrue(taskService.getTaskList().isEmpty());
	}
	
	@Test
	void testUpdate() {
		var taskService = new TaskService();
		
		
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			taskService.UpdateTask(null, "update", 0);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			taskService.UpdateTask("12345678", null, 0);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			taskService.UpdateTask("123456", "update", -1);
		});
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			taskService.UpdateTask("123456789109", "update", 0);
		});
		
		
		// list is empty
		taskService.UpdateTask("123456", "update", 1);
		
		// add task
		taskService.addTask("new task name", "new task description");
		Task task = taskService.getTaskList().get(0);
		
		// default remove
		taskService.UpdateTask(task.getID(), "update", 0);
		
		// task not in list
		taskService.UpdateTask("123456", "Name", 1);
		
		// update task name
		taskService.UpdateTask(task.getID(), "New Task Name", 1);
		assertEquals("New Task Name", taskService.getTaskList().get(0).getTaskName());
		
		// update with bad name
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			taskService.UpdateTask(task.getID(), "task name is waywaywaywaywaywaywaywayway too long.", 1);
		});
		
		// update task description
		taskService.UpdateTask(task.getID(), "new task description.", 2);
		assertEquals("new task description.", taskService.getTaskList().get(0).getTaskDescription());
		
		// update with bad description
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			taskService.UpdateTask(task.getID(), "task description is waywaywaywaywaywaywaywaywaywayway"
					+ " waywaywaywaywaywayway too long I think", 2);
		});
		
	}
	
	
	

	
	
}