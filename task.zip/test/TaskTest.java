package test;
import task.Task;



import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;


import org.junit.jupiter.api.Test;
import task.TaskService;
class TaskTest {

	@Test
	void testTask() {
		// id too long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("12345678901234", "taskName", "taskDescription");
		});
		// name too long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", "taskNameiswaytoolongIthink", "taskDescription");
		});
		// description too long
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", "taskName", "taskDescriptioniswaywaywaywaywaywaywayway"
					+ "waywaywaywaywaywaywaywaywaywaywaywaywaywaywaywaywaytoolongIthink.");
		});
		// null id
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task(null, "taskName", "taskDescription");
		});
		// name null
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", null, "taskDescription");
		});
		// description null
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Task("1234567890", "taskName", null);
		});
		
	}
	
	@Test
	void testTaskGetters() {
		Task task = new Task("1234567890", "task Name", "task Description");
		assertTrue(task.getID().equals("1234567890"));
		assertTrue(task.getTaskName().equals("task Name"));
		assertTrue(task.getTaskDescription().equals("task Description"));
	}
	
	void testTaskSetters() {
		Task task = new Task("1234567890", "task Name", "task Description");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			task.setTaskName(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			task.setTaskName("task Name is Waywaywaywayway Too Long");
		});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			task.setTaskDescription(null);
		});
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			task.setTaskDescription(" task description is waywaywaywaywayway"
					+ "waywaywaywaywaywayway too long I thinks");
		});
		task.setTaskName("new Name");
		task.setTaskDescription("new Description");
		assertTrue(task.getTaskName().equals("new Name"));
		assertTrue(task.getTaskDescription().equals("new Description"));
	}

}
		


